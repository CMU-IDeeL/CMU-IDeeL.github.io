# Title

# This is title 
## This is subtitle
### This is sub-subtitle
#### ...

## Build lists

* First list
  * Second list
    * third list

## Super Link

[LINK](www.google.com)


## Front style

```
1. character shading
```

*2. Slanted font*

**3. Bold**

---
4.Separator


## Equation 
\\[ a \cdot b = \| a \| \| b \| \cos \theta \\]
For more information, please refer to [this link](https://en.wikibooks.org/wiki/LaTeX/Mathematics)

## Images
![Image of Einstein](https://upload.wikimedia.org/wikipedia/commons/6/6f/Einstein-formal_portrait-35.jpg)

