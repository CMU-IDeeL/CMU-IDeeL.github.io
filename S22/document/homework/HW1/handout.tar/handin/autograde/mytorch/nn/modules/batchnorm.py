import numpy as np

class BatchNorm1d:

    def __init__(self, num_features, alpha=0.9):

        # You shouldn't need to edit anything in init

        self.alpha = alpha
        self.eps = 1e-8

        self.N = None # the batch_size

        self.Z = None
        self.NZ = None
        self.BZ = None

        # The following attributes will be tested
        self.V = np.ones((1, num_features))
        self.M = np.zeros((1, num_features))

        self.BW = np.ones((1, num_features))
        self.dLdBW = np.zeros((1, num_features))

        self.Bb = np.zeros((1, num_features))
        self.dLdBb = np.zeros((1, num_features))

        # inference parameters
        self.running_M = np.zeros((1, num_features))
        self.running_V = np.ones((1, num_features))

    def __call__(self, Z, eval=False):
        return self.forward(Z, eval)

    def forward(self, Z, eval=False):
        """
        Argument:
            x (np.array): (batch_size, num_features)
            eval (bool): inference status

        Return:
            out (np.array): (batch_size, num_features)

        NOTE: The eval parameter is to indicate whether we are in the 
        training phase of the problem or are we in the inference phase.
        So see what values you need to recompute when eval is True.
        """
        self.Z = Z
        self.N = batch_size = Z.shape[0]
        
        if eval:
            self.NZ = (self.Z - self.running_M) / np.sqrt(self.running_V + self.eps)
            self.BZ = self.BW * self.NZ + self.Bb

        else:
            self.M = np.mean(Z, axis=0)
            self.V = np.var(Z, axis=0)
            self.NZ = (self.Z - self.M) / np.sqrt(self.V + self.eps)
            # print('self.NZ = ', self.NZ)
            self.BZ = self.BW * self.NZ + self.Bb

            # Update running batch statistics
            self.running_M = (self.alpha * self.running_M) + (1-self.alpha) * self.M
            self.running_V = (self.alpha * self.running_V) + (1-self.alpha) * self.V
        
        return self.BZ

    def backward(self, dLdBZ):
        """
        Argument:
            dLdBZ (np.array): (batch size, num_features)
        Return:
            out (np.array): (batch size, num_features)
        """

        batch_size = self.Z.shape[0]
        sqrt_var_eps = np.sqrt(self.V + self.eps)
        self.dLdBW = np.sum(self.NZ * dLdBZ, axis = 0, keepdims=True)
        self.dLdBb = np.sum(dLdBZ, axis = 0, keepdims = True)

        #Find the derivative of norm
        gradNorm = self.BW * dLdBZ
        #Find the derivative of variance 
        gradVar = -0.5 * np.sum((gradNorm * (self.Z-self.M) / (sqrt_var_eps**(3))), axis = 0)

        #Find the derivative of the mean. Again, looks harder than it
        first_term_dmu = -(np.sum(gradNorm/sqrt_var_eps, axis= 0))
        second_term_dmu = - (2/batch_size)*(gradVar)*(np.sum(self.Z-self.M, axis= 0))
        gradMu = first_term_dmu + second_term_dmu

        first_term_dx = gradNorm/sqrt_var_eps
        second_term_dx = gradVar * (2/batch_size) * (self.Z-self.M)
        third_term_dx = gradMu * (1/batch_size)

        return first_term_dx + second_term_dx + third_term_dx