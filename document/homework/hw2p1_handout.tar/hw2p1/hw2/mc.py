# Multiple Choice

# Return the answer to the multiple choice question in the handout.
# If you think option c is the correct answer,
# return 'c'

def question_1():
    raise NotImplemented

def question_2():
    raise NotImplemented

def question_3():
    raise NotImplemented

def question_4():
    raise NotImplemented

def question_5():
    raise NotImplemented
