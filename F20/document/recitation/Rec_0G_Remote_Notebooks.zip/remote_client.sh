ssh -i ~/adam-11785.pem -N -f -L localhost:11786:localhost:8889 ubuntu@ec2-34-222-24-24.us-west-2.compute.amazonaws.com
