"""
A simple log module created for 785 students. Using this log, we would not lose
the output from the terminal or jupyter notebook because it could be stored in
non-volatile storage.

Author: Adam Zhang
Date: 7/11/2020
"""
import datetime, os
class Log(object):
    def __init__(self, stdout=True, file_path=None, start_from_new=False):
        """
        file_path: The log file path. If None, then the log would only be printed to the standard out.
        start_from_new: If True, this would erase the old log.
        """
        self.stdout = stdout
        self.file_path = file_path
        self.file = None
        if self.file_path is not None:
            if start_from_new:
                if os.path.exists(self.file_path):
                    os.remove(self.file_path)
            self.file = open(self.file_path, "a")
            
    def printf(self, msg):
        time = datetime.datetime.now()
        msg = "{}: {}".format(time, msg)
        if self.stdout:
            print(msg)
        if self.file:
            self.file.write(msg + '\n')
            self.file.flush()
            
    def __del__(self):
        if self.file is not None:
            self.file.flush()
            self.file.close()