import sys
import numpy as np
from torch import nn

sys.path.append('autograder')
sys.path.append('./')
sys.path.append('handin')

from test_util import *
from mytorch.nn.gru import GRUUnit, GRU
from mytorch.nn.util import pack_sequence, unpack_sequence

def transfer_weights_GRU(src,dest,hs):
    
    i = 0 

    dest.unit.weight_ir.data = getattr(src,'weight_ih_l{}'.format(i))[:hs].detach().numpy()
    dest.unit.weight_iz.data = getattr(src,'weight_ih_l{}'.format(i))[hs:2*hs].detach().numpy()
    dest.unit.weight_in.data = getattr(src,'weight_ih_l{}'.format(i))[2*hs:].detach().numpy()
    
    dest.unit.bias_ir.data = getattr(src,'bias_ih_l{}'.format(i))[:hs].detach().numpy()
    dest.unit.bias_iz.data = getattr(src,'bias_ih_l{}'.format(i))[hs:2*hs].detach().numpy()
    dest.unit.bias_in.data = getattr(src,'bias_ih_l{}'.format(i))[2*hs:].detach().numpy()


    dest.unit.weight_hr.data = getattr(src,'weight_hh_l{}'.format(i))[:hs].detach().numpy()
    dest.unit.weight_hz.data = getattr(src,'weight_hh_l{}'.format(i))[hs:2*hs].detach().numpy()
    dest.unit.weight_hn.data = getattr(src,'weight_hh_l{}'.format(i))[2*hs:].detach().numpy()
    
    dest.unit.bias_hr.data = getattr(src,'bias_hh_l{}'.format(i))[:hs].detach().numpy()
    dest.unit.bias_hz.data = getattr(src,'bias_hh_l{}'.format(i))[hs:2*hs].detach().numpy()
    dest.unit.bias_hn.data = getattr(src,'bias_hh_l{}'.format(i))[2*hs:].detach().numpy()

def transfer_weights_gru_unit(src, dest, hs):
    dest.weight_ir.data = getattr(src,'weight_ih')[:hs].detach().numpy()
    dest.weight_iz.data = getattr(src,'weight_ih')[hs:2*hs].detach().numpy()
    dest.weight_in.data = getattr(src,'weight_ih')[2*hs:].detach().numpy()
        
    dest.bias_ir.data = getattr(src,'bias_ih')[:hs].detach().numpy()
    dest.bias_iz.data = getattr(src,'bias_ih')[hs:2*hs].detach().numpy()
    dest.bias_in.data = getattr(src,'bias_ih')[2*hs:].detach().numpy()

    dest.weight_hr.data = getattr(src,'weight_hh')[:hs].detach().numpy()
    dest.weight_hz.data = getattr(src,'weight_hh')[hs:2*hs].detach().numpy()
    dest.weight_hn.data = getattr(src,'weight_hh')[2*hs:].detach().numpy()
        
    dest.bias_hr.data = getattr(src,'bias_hh')[:hs].detach().numpy()
    dest.bias_hz.data = getattr(src,'bias_hh')[hs:2*hs].detach().numpy()
    dest.bias_hn.data = getattr(src,'bias_hh')[2*hs:].detach().numpy()

def test_gru():
    input_size, hidden_size, num_layers, bidirectional, data = get_params()
    data_a = np.asarray(data)

    tx_pack = get_torch_pack(data)
    mx_pack = get_mytorch_pack(data)

    modelGRU = nn.GRU(input_size,hidden_size,num_layers, bidirectional=bidirectional)
    model2GRU = GRU(input_size,hidden_size,num_layers,bidirectional=bidirectional)

    transfer_weights_GRU(modelGRU,model2GRU,num_layers,hidden_size,bidirectional)

    resmgru, hiddenmgru = model2GRU(mx_pack)
    restgru, hiddentgru = modelGRU(tx_pack)

    compare_ps(restgru, resmgru.data, "test_gru")
    return True

def test_gru_unit_forward2():
    input_size, hidden_size, num_layers, bidirectional, data = get_params()

    tx_pack = get_torch_data(data)
    mx_pack = get_mytorch_data(data)

    model = nn.GRUCell(input_size, hidden_size)
    rest = model(tx_pack)

    model2 = GRUUnit(input_size, hidden_size)
    transfer_weights_gru_unit(model,model2, hidden_size)
    resm = model2(mx_pack)

    compare_ps(rest, resm, "test_gru_cell_forward")
    

def test_gru_unit_forward():
    input_size, hidden_size, num_layers, bidirectional, data = get_params()

    tx_pack = get_torch_data(data)
    mx_pack = get_mytorch_data(data)

    model = nn.GRUCell(input_size, hidden_size)
    model2 = GRUUnit(input_size, hidden_size)
    transfer_weights_gru_unit(model,model2,hidden_size)
    
    resm = model2(mx_pack)
    rest = model(tx_pack)
    
    compare_ps(rest, resm, "test_gru_unit_forward")

    return True

def test_gru_unit_backward():
    input_size, hidden_size, num_layers, bidirectional, data = get_params()
    
    tx_pack = get_torch_data(data)
    tx_pack.requires_grad = True

    mx_pack = get_mytorch_data(data)
    mx_pack.requires_grad = True

    model = nn.GRUCell(input_size, hidden_size)
    model2 = GRUUnit(input_size, hidden_size)
    transfer_weights_gru_unit(model,model2,hidden_size)
    
    resm = model2(mx_pack)
    rest = model(tx_pack)
    
    lm = (resm**2).sum()
    lt = (rest**2).sum()

    lm.backward()
    lt.backward()
    
    a = compare_gru_unit_param_grad(model,model2,hidden_size)
    a = a and check_grad(mx_pack,tx_pack)

    return a

def test_GRU_forward():
    input_size, hidden_size, num_layers, bidirectional, data = get_params()

    shape1 = (3,3)
    shape2 = (5,3)
    shape3 = (4,3)

    a = tensor.Tensor.randn(*shape1)
    b = tensor.Tensor.randn(*shape2)
    c = tensor.Tensor.randn(*shape3)

    seq1 = [a,b,c]
    input = pack_sequence(seq1)
 
    a_torch = get_same_torch_tensor_float(a)
    b_torch = get_same_torch_tensor_float(b)
    c_torch = get_same_torch_tensor_float(c)

    seq2 = [a_torch, b_torch, c_torch ]
    input_pt = nn.utils.rnn.pack_sequence(seq2, enforce_sorted=False)

    time_itr = GRU(input_size, hidden_size)
    rnn = nn.GRU(input_size = input_size, hidden_size = hidden_size, num_layers = 1, batch_first=False)

    transfer_weights_GRU(rnn,time_itr,hidden_size)

    res_pt, h_pt  = rnn(input_pt)
    res_mt, h_mt = time_itr.forward(input)
    
    # Slight differences b/w our RNN and PyTorch RNN.
    # PyTorch RNN return has extra dimension for num_directions
    # Also PyTorch sorts the hidden states but we don't

    compare_ps(res_pt, res_mt.data, "test_rnn_unit_forward")
    a = check_val(h_mt,h_pt[0][[2,0,1]])

    return a
