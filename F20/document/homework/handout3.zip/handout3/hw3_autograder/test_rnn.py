import sys
import numpy as np
import torch
from torch import nn

sys.path.append('autograder')
sys.path.append('./')
sys.path.append('handin')
from mytorch.tensor import Tensor
from mytorch.nn.rnn import RNN
from mytorch.nn.rnn import RNNUnit, TimeIterator
from mytorch.nn.util import pack_sequence as mpack_sequence
from test_util import *

def transfer_weights(src,dest):
    # Assuming src to be a pytorch model
    # Assuming dest to be a mytorch model
    
    i=0

    dest.unit.weight_ih.data = getattr(src,'weight_ih_l{}'.format(i)).detach().numpy()
    dest.unit.weight_hh.data = getattr(src,'weight_hh_l{}'.format(i)).detach().numpy()
    dest.unit.bias_ih.data = getattr(src,'bias_ih_l{}'.format(i)).detach().numpy()
    dest.unit.bias_hh.data = getattr(src,'bias_hh_l{}'.format(i)).detach().numpy()


def test_rnn():
    input_size, hidden_size, num_layers, bidirectional, data = get_params()

    tx_pack = get_torch_data(data)
    mx_pack = get_mytorch_data(data)

    model = nn.RNN(input_size,hidden_size,num_layers,bidirectional=bidirectional)
    rest, hiddent = model(tx_pack)

    model2 = RNN2(input_size,hidden_size,num_layers,bidirectional=bidirectional)
    transfer_weights(model,model2,num_layers,bidirectional)
    resm, hiddenm = model2(mx_pack)

    print('rest:',rest)
    print('hiddent:',hiddent)

    print('resm:',resm)
    print('hiddenm:',hiddenm)

    compare_ps(rest,resm, "test_rnn")
    return True

def test_rnn_unit_forward():
    input_size, hidden_size, num_layers, bidirectional, data = get_params()

    tx_pack = get_torch_data(data)
    mx_pack = get_mytorch_data(data)

    model = nn.RNNCell(input_size, hidden_size)
    model2 = RNNUnit(input_size, hidden_size)
    transfer_weights_rnn_unit(model,model2)
    
    resm = model2(mx_pack)
    rest = model(tx_pack)
    
    compare_ps(rest, resm, "test_rnn_unit_forward")

    return True

def test_rnn_unit_backward():
    input_size, hidden_size, num_layers, bidirectional, data = get_params()
    
    tx_pack = get_torch_data(data)
    tx_pack.requires_grad = True

    mx_pack = get_mytorch_data(data)
    mx_pack.requires_grad = True

    model = nn.RNNCell(input_size, hidden_size)
    model2 = RNNUnit(input_size, hidden_size)
    transfer_weights_rnn_unit(model,model2)
    
    resm = model2(mx_pack)
    rest = model(tx_pack)
    
    lm = (resm**2).sum()
    lt = (rest**2).sum()

    lm.backward()
    lt.backward()
    
    a = compare_rnn_unit_param_grad(model,model2)
    a = a and check_grad(mx_pack,tx_pack)

    return a

def test_time_iterator_forward():
    input_size, hidden_size, num_layers, bidirectional, data = get_params()

    shape1 = (3,3)
    shape2 = (5,3)
    shape3 = (4,3)

    a = Tensor.randn(*shape1)
    b = Tensor.randn(*shape2)
    c = Tensor.randn(*shape3)

    seq1 = [a,b,c]
    input = mpack_sequence(seq1)
 
    a_torch = get_same_torch_tensor_float(a)
    b_torch = get_same_torch_tensor_float(b)
    c_torch = get_same_torch_tensor_float(c)

    seq2 = [a_torch, b_torch, c_torch ]
    input_pt = nn.utils.rnn.pack_sequence(seq2, enforce_sorted=False)

    time_itr = RNN(input_size, hidden_size)
    rnn = nn.RNN(input_size = input_size, hidden_size = hidden_size, num_layers = 1, batch_first=False)

    transfer_weights(rnn,time_itr)

    res_pt, h_pt  = rnn(input_pt)
    res_mt, h_mt = time_itr.forward(input)
    
    # Slight differences b/w our RNN and PyTorch RNN.
    # PyTorch RNN return has extra dimension for num_directions
    # Also PyTorch sorts the hidden states but we don't

    compare_ps(res_pt, res_mt.data, "test_rnn_unit_forward")
    a = check_val(h_mt,h_pt[0][[2,0,1]])

    return a

def test_time_iterator_backward():
    input_size, hidden_size, num_layers, bidirectional, data = get_params()

    shape1 = (3,3)
    shape2 = (5,3)
    shape3 = (4,3)

    a = Tensor.randn(*shape1)
    b = Tensor.randn(*shape2)
    c = Tensor.randn(*shape3)
    
    a.requires_grad = True
    b.requires_grad = True
    c.requires_grad = True

    seq1 = [a,b,c]
    input = mpack_sequence(seq1)
     
    a_torch = get_same_torch_tensor_float(a)
    b_torch = get_same_torch_tensor_float(b)
    c_torch = get_same_torch_tensor_float(c)

    a_torch.requires_grad = True
    b_torch.requires_grad = True
    c_torch.requires_grad = True
    
    seq2 = [a_torch, b_torch, c_torch ]
    input_pt = nn.utils.rnn.pack_sequence(seq2, enforce_sorted=False)

    time_itr = RNN(input_size, hidden_size)
    rnn = nn.RNN(input_size = input_size, hidden_size = hidden_size, num_layers = 1, batch_first=False)

    transfer_weights(rnn,time_itr)

    res_pt, h_pt  = rnn(input_pt)
    res_mt, h_mt = time_itr.forward(input)
    
    lm = (res_mt.data**2).sum()
    lt = (res_pt.data**2).sum()

    lm.backward()
    lt.backward()
    
    a = compare_rnn_param_grad(rnn,time_itr)

    for pa, ma in zip(seq2,seq1):
        a = a and check_grad(ma,pa)

    return a
