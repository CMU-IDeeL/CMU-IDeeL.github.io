import sys
import numpy as np
import torch
import math
from test_util import *
from helpers import assertions_all

sys.path.append('./')
sys.path.append('autograder')
from mytorch.autograd_engine import *
from mytorch.tensor import Tensor
from mytorch.nn.util import pack_sequence, unpack_sequence

eps = 1e-6

def test_concat():
    # shape of tensor to test
    shape1 = (1, 4, 3)
    shape2 = (1, 8, 3)

    # get mytorch and torch tensor: 'a'
    a = Tensor.randn(*shape1)
    a.requires_grad = True
    a_torch = get_same_torch_tensor(a)

    # get mytorch and torch tensor: 'b'
    b = Tensor.randn(*shape2)
    b.requires_grad = True
    b_torch = get_same_torch_tensor(b)

    # run mytorch and torch forward: 'c = cat (a, b)'
    ctx = ContextManager()
    seq = [a,b]
    c = Cat.forward(ctx, 1, *seq)
    c_torch = torch.cat((a_torch,b_torch), dim=1)

    _, *back = Cat.backward(ctx, c)
    c_torch.sum().backward()

    assert check_val_and_grad(c, c_torch)
    assert check_val(back[0], a_torch)
    assert check_val(back[1], b_torch)
    
    ######## test non existent dim #########

    shape1 = (1, 2, 3)
    shape2 = (1, 8)

    # get mytorch and torch tensor: 'a'
    a = Tensor.randn(*shape1)
    a.requires_grad = True
    a_torch = get_same_torch_tensor(a)

    # get mytorch and torch tensor: 'b'
    b = Tensor.randn(*shape2)
    b.requires_grad = True
    b_torch = get_same_torch_tensor(b)
    seq = [a,b]
    try:
        c = Cat.forward(ctx, 1, *seq)
        print("Error: Tensor concatenating objects of non-matching dimensions")
        return False
    except:
        pass

    return True

def test_slice():
    # shape of tensor to test
    shape = (2, 4, 3)

    # get mytorch and torch tensor: 'a'
    a = Tensor.randn(*shape) #mytorch tensor
    a.requires_grad = True
    a_torch = get_same_torch_tensor(a) #pytorch tensor
    ctx = ContextManager()

    # Test 1
    b = a[1,2,0]
    b_torch = a_torch[1,2,0]
    compare_ps(b_torch, b,"test_slice")

    a[1,2,0].backward()
    a_torch_back = torch.tensor(a.grad.data)
    assertions_no_type(torch.nonzero(a_torch_back, as_tuple=False), torch.tensor([[1, 2, 0]]),"test_slice")

    # Test 2
    b = a[0,2,:]
    b_torch = a_torch[0,2,:]
    compare_ps(b_torch, b,"test_slice")

    a[0,2,:].backward()
    a_torch_back = torch.tensor(a.grad.data)
    assertions_no_type(torch.nonzero(a_torch_back, as_tuple=False), torch.tensor([[0, 2, 0],[0, 2, 1],
                                                            [0, 2, 2],[1, 2, 0]]), "test_slice")

    # Test 3
    b = a[:,3,:]
    b_torch = a_torch[:,3,:]
    compare_ps(b_torch, b,"test_slice")

    a[:,3,:].backward()
    a_torch_back = torch.tensor(a.grad.data)
    assertions_no_type(torch.nonzero(a_torch_back, as_tuple=False), torch.tensor([[0, 2, 0],
                        [0, 2, 1],[0, 2, 2],[0, 3, 0],[0, 3, 1],[0, 3, 2],
                        [1, 2, 0],[1, 3, 0],[1, 3, 1],[1, 3, 2]]),"test_slice")

    # Test 4
    b = a[:,:,1]
    b_torch = a_torch[:,:,1]
    compare_ps(b_torch, b,"test_slice")

    a[:,:,1].backward()
    a_torch_back = torch.tensor(a.grad.data)
    assertions_no_type(torch.nonzero(a_torch_back, as_tuple=False), torch.tensor([[0, 0, 1],[0, 1, 1],
                        [0, 2, 0],[0, 2, 1],[0, 2, 2],[0, 3, 0],[0, 3, 1],
                        [0, 3, 2],[1, 0, 1],[1, 1, 1],[1, 2, 0],[1, 2, 1],
                        [1, 3, 0],[1, 3, 1],[1, 3, 2]]),"test_slice")

    return True

def test_unsqueeze():
    # shape of tensor to test
    shape = (2, 2, 3)

    # get mytorch and torch tensor: 'a'
    a = Tensor.randn(*shape) #mytorch tensor
    a.requires_grad = True
    a_torch = get_same_torch_tensor(a) #pytorch tensor

    b = Tensor.unsqueeze(a)
    b_torch = torch.Tensor.unsqueeze(a_torch, 0)
    compare_ps(b_torch, b,"test_unsqueeze")
    
    b = Tensor.unsqueeze(a, 2)
    b_torch = torch.Tensor.unsqueeze(a_torch, 2)
    compare_ps(b_torch, b,"test_unsqueeze")
    
    return True

def test_pack_sequence_forward():
    
    test_shapes = [[(4,1),(5,1)],
                   [(4,3),(10,3),(2,3)]]
    
    a = True
    for shapes in test_shapes:
        # get mytorch and torch tensor: 'a'
        seq1 = [Tensor.randn(*shape) for shape in shapes]
        seq2 = [ get_same_torch_tensor(t) for t in seq1 ]
    
        # run mytorch and torch forward: 'c = cat (a, b)'
        c = pack_sequence(seq1)
        c_torch = torch.nn.utils.rnn.pack_sequence(seq2, enforce_sorted=False)
        a = a and check_val(c.data,c_torch.data)
        #compare_ps(c_torch, c.data, "test_pack_sequence_forward")
        a = a and compare_ndarrays(c.batch_sizes, c_torch.batch_sizes)
        a = a and compare_ndarrays(c.sorted_indices, c_torch.sorted_indices)
    
    return a 


def test_pack_sequence_backward():
    
    test_shapes = [[(4,1),(5,1)],
                   [(4,3),(10,3),(2,3)]]
    
    a = True
    for shapes in test_shapes:
        # get mytorch and torch tensor: 'a'
        seq1 = [Tensor.randn(*shape) for shape in shapes]
        for t in seq1:
            t.requires_grad = True

        seq2 = [ get_same_torch_tensor(t) for t in seq1 ]
    
        # run mytorch and torch forward: 'c = cat (a, b)'
        c = pack_sequence(seq1)
        c_torch = torch.nn.utils.rnn.pack_sequence(seq2, enforce_sorted=False)
        
        l = (c.data**2).sum()
        l_torch = (c_torch.data**2).sum()

        l.backward()
        l_torch.backward()
        
        for a1, a2 in zip(seq1, seq2):
            a = a and check_grad(a1,a2, eps = eps)
        #compare_ps(c_torch, c.data, "test_pack_sequence_backward")
    
    return a


def test_unpack_sequence_forward():
    
    test_shapes = [[(4,1),(5,1),(2,1),(2,1),(3,1)],
                   [(4,3),(10,3),(2,3)]]

    for shapes in test_shapes:
        # get mytorch and torch tensor: 'a'
        seq1 = [Tensor.randn(*shape) for shape in shapes]
        
        # run mytorch and torch forward: 'c = cat (a, b)'
        c = pack_sequence(seq1)
        seq2 = unpack_sequence(c)
        
        for s1,s2 in zip(seq1,seq2): 
            compare_ps_tensor(s1,s2, '')
    
    return True 

def test_unpack_sequence_backward():
    
    test_shapes = [[(4,1),(5,1)],
                   [(4,3),(10,3),(2,3)]]
    a = True
    for shapes in test_shapes:
        # get mytorch and torch tensor: 'a'
        seq1 = [Tensor.randn(*shape) for shape in shapes]
        for t in seq1:
            t.requires_grad = True

        seq2 = [ get_same_torch_tensor(t) for t in seq1 ]
    
        # run mytorch and torch forward: 'c = cat (a, b)'
        c_temp = pack_sequence(seq1)
        c_temp2 = unpack_sequence(c_temp)
        c = pack_sequence(c_temp2)

        c_torch = torch.nn.utils.rnn.pack_sequence(seq2, enforce_sorted=False)
        
        l = (c.data**2).sum()
        l_torch = (c_torch.data**2).sum()

        l.backward()
        l_torch.backward()
        
        for a1, a2 in zip(seq1, seq2):
            a = a and check_grad(a1,a2, eps = eps)
        #compare_ps(c_torch, c.data, "test_pack_sequence_backward")
    
    return a
