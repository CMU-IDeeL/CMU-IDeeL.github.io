tar -cvf handin.tar --exclude=*pycache* mytorch hw1 hw2 hw3 hw4
