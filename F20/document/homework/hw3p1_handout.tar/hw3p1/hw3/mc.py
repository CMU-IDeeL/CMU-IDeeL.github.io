# You know the drill...

def question_1():
    raise NotImplemented

def question_2():
    raise NotImplemented

def question_3():
    raise NotImplemented

def question_4():
    raise NotImplemented
