tar -cvf handin.tar models mytorch 

