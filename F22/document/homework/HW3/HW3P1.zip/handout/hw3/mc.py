# You know the drill...


def question_1():
    raise NotImplementedError


def question_2():
    raise NotImplementedError


def question_3():
    raise NotImplementedError


def question_4():
    raise NotImplementedError
