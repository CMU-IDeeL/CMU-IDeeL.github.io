import numpy as np

x = 10
print(x)