tar -cvf handin.tar -X exclude.txt hw2 mytorch 

